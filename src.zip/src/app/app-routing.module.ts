import { ContactComponent } from './contact/contact.component';
import { BookappointmentComponent } from './bookappointment/bookappointment.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: "welcome", component:WelcomeComponent
  },
  {
    path: "viewappointment", component:ViewappointmentComponent
  },
  {
    path: "bookappointment", component:BookappointmentComponent
  },
  {
    path: "contact", component:ContactComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
